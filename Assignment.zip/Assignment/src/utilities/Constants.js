export const storyTypes = {
  NEW: "newstories",
  BEST: "beststories",
  TOP: "topstories",
};

export const limit = 10;

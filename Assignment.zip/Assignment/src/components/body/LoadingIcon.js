import React from "react";

const LoadingIcon = () => (
  <div className="loadingio-spinner-bars-ou4wi5t900s">
    <div className="ldio-hy4ytz1hdz">
      <div></div>
      <div></div>
      <div></div>
      <div></div>
    </div>
  </div>
);

export default LoadingIcon;

# hackernews_clone

A web app clone of hacker news.  
Checkout [Demo Site](https://frosty-volhard-7d242c.netlify.app/)

# Topics covered

- useRef
- useState
- useEffect
- Axios (API calls)
- React routing


Dom Routing
Nav link Bar
Pagination